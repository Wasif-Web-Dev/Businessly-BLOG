import React from 'react'
import Category from './Category'

function InteractiveSessions() {
  return (
    <div>
        <Category text='InteractiveSessions'/>
    </div>
  )
}

export default InteractiveSessions